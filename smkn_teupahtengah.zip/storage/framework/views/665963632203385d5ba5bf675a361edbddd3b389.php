

<?php $__env->startSection('container'); ?>
<div class="card">
    <div class="card-header">
      <h3 class="card-title">Detail Berita</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="row">
            <div class="col-12">
                <h2 class="text-center"><?php echo e($berita->judul); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" class="img-thumbnail" width="400px">
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <p><?php echo $berita->body; ?></p>
            </div>
        </div>
    </div>
    <!-- /.card-body -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/berita/show.blade.php ENDPATH**/ ?>