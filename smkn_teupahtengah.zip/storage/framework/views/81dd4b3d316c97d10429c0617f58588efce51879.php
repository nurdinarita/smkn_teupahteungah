

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            <?php echo e(isset($fasilitas) ? 'Edit Fasilitas' : 'Tambah Fasilitas'); ?>

          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(isset($fasilitas) ? url('admin/fasilitas/'.$fasilitas->id) : url('admin/fasilitas/')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($fasilitas)): ?>
            <?php echo method_field('patch'); ?>
            <?php endif; ?>
            <div class="mb-1">
              <label for="nama">Nama Fasilitas</label>
              <input type="text" class="form-control" name="nama" id="nama" value="<?php echo e(isset($fasilitas) ? $fasilitas->nama : old('nama')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="luas">Luas</label>
              <input type="text" class="form-control" name="luas" id="luas" value="<?php echo e(isset($fasilitas) ? $fasilitas->luas : old('luas')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="kondisi">Kondisi</label>
              <select name="kondisi" id="kondisi" class="form-control" required>
                <option value="">-- Pilih Kondisi --</option>
                <option value="Layak Pakai" <?php echo e(isset($fasilitas) && $fasilitas->kondisi == 'Layak Pakai' ? 'selected' : ''); ?>>Layak Pakai</option>
                <option value="Tidak Layak Pakai" <?php echo e(isset($fasilitas) && $fasilitas->kondisi == 'Tidak Layak Pakai' ? 'selected' : ''); ?>>Tidak Layak Pakai</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/fasilitas/form.blade.php ENDPATH**/ ?>