

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            <?php echo e(isset($guru) ? 'Edit Data Guru' : 'Tambah Data Guru'); ?>

          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(isset($guru) ? url('admin/guru/'.$guru->id) : url('admin/guru/')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($guru)): ?>
            <?php echo method_field('patch'); ?>
            <?php endif; ?>
            <div class="mb-1">
              <label for="nip">NIP</label>
              <input type="text" class="form-control" name="nip" id="nip" value="<?php echo e(isset($guru) ? $guru->nip : old('nip')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="nama">Nama Guru</label>
              <input type="text" class="form-control" name="nama" id="nama" value="<?php echo e(isset($guru) ? $guru->nama : old('nama')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="mata_pelajaran">Mata Pelajaran</label>
              <input type="text" class="form-control" name="mata_pelajaran" id="mata_pelajaran" value="<?php echo e(isset($guru) ? $guru->mata_pelajaran : old('mata_pelajaran')); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/guru/form.blade.php ENDPATH**/ ?>