

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Profil Sekolah</h4>
            <?php if(isset($profil)): ?>
            <p>
                <?php echo $profil->profil; ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
</section>

<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Visi Dan Misi</h4>
            <?php if(isset($visimisi)): ?>
            <div class="row">
                <div class="col-md-12">
                    <h3>Visi</h3>
                    <?php echo $visimisi->visi; ?>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h3>Misi</h3>
                    <?php echo $visimisi->misi; ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Struktur Organisasi</h4>

            <?php if(isset($struktur)): ?>
            <div class="text-center">
                <h5>Tahun : <?php echo e($struktur->tahun); ?></h5>
                <img src="<?php echo e(asset('storage/'.$struktur->gambar)); ?>" class="img-thumbnail" width="70%">
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/profil.blade.php ENDPATH**/ ?>