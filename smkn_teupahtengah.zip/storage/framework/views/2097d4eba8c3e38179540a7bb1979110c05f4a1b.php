

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            Edit Profil Sekolah
          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(url('admin/profil/'.$profil->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <textarea id="summernote" name="profil" required>
              <?php echo $profil->profil; ?>

            </textarea>
            <button type="submit" class="btn btn-primary">Update Profil</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/profil/form.blade.php ENDPATH**/ ?>