

<?php $__env->startSection('container'); ?>
<div class="container-fluid">

<div class="card m-5">
    <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" class="img-fluid" style="height: 450px;">
    <div class="card-body">
      <h5 class="card-title"><?php echo e($berita->judul); ?></h5>
      <p class="card-text"><?php echo $berita->body; ?></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/beritaSingle.blade.php ENDPATH**/ ?>