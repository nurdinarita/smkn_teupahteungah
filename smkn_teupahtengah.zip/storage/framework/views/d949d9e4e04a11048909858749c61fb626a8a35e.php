

<?php $__env->startSection('container'); ?>
<div class="card">
    <div class="card-header">
      <h3 class="card-title">Dewan Guru</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <a href="<?php echo e(url('admin/guru/create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Guru</a>
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr>
          <th class="col-1">No</th>
          <th>NIP</th>
          <th>Nama Guru</th>
          <th>Mata Pelajaran</th>
          <th class="col-2">Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($guru->nip); ?></td>
          <td><?php echo e($guru->nama); ?></td>
          <td><?php echo e($guru->mata_pelajaran); ?></td>
          <td class="text-center">
            <a href="<?php echo e(url('admin/guru/'.$guru->id.'/edit')); ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i>
            </a>
            <button class="btn btn-danger" data-toggle="modal" data-target="#deleteModal" data-url=<?php echo e(url('admin/guru/'.$guru->id)); ?>>
                <i class="fas fa-trash-alt"></i>
            </button>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
          <th>No</th>
          <th>NIP</th>
          <th>Nama Guru</th>
          <th>Mata Pelajaran</th>
          <th>Aksi</th>
        </tr>
        </tfoot>
      </table>
    </div>
    <!-- /.card-body -->
</div>

<!-- Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Yakin ingin menghapus data ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <form method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button type="submit" class="btn btn-danger">Hapus</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script-hapus'); ?>
<script>
    $('#deleteModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var url = button.data('url') // Extract info from data-* attributes
       
        var modal = $(this)

        modal.find('.modal-footer form').attr("action", url)
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/guru/index.blade.php ENDPATH**/ ?>