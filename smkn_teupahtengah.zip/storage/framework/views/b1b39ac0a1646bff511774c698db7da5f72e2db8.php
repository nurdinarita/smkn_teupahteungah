

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            <?php echo e(!isset($berita) ? 'Tambah Berita Sekolah' : 'Edit Berita Sekolah'); ?>

          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(isset($berita) ? url('admin/berita/'.$berita->id) : url('admin/berita/')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($berita)): ?>
            <?php echo method_field('patch'); ?>
            <?php endif; ?>
            <div class="mb-1">
              <label for="judul">Judul</label>
              <input type="text" name="judul" class="form-control" id="judul" placeholder="Judul" value="<?php echo e(isset($berita) ? $berita->judul : old('judul')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="slug">Slug</label>
              <input type="text" name="slug" class="form-control" id="slug" placeholder="Slug" value="<?php echo e(isset($berita) ? $berita->slug : old('slug')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="gambar">Gambar</label>
              <?php if(isset($berita)): ?>
                <br>
                <img src="<?php echo e(asset('storage/'.$berita->gambar)); ?>" alt="" class="img-thumbnail" width="200px">
              <?php endif; ?>
              <input type="file" class="form-control" name="gambar" id="gambar">
            </div>
            <div class="mb-1">
              <label for="summernote">Isi Berita</label>
              <textarea id="summernote" name="body" required>
                <?php echo isset($berita) ? $berita->body : old('body'); ?>

              </textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slug'); ?>
<script>
    $('#judul').change(function(e) {
       $.get('<?php echo e(url('checkSlug')); ?>', 
       { 'judul': $(this).val() }, 
       function( data ) {
           $('#slug').val(data.slug);
       }
       );
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/berita/form.blade.php ENDPATH**/ ?>