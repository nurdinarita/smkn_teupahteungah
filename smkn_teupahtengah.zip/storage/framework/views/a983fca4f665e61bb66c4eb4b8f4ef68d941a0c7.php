

<?php $__env->startSection('container'); ?>
<div class="container-fluid">

<section>
<div class="row">
    <div class="col-md-7 mt-4">
        <h4 class="bg-secondary text-center text-light p-1">Berita Sekolah</h4>

        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <img src="<?php echo e(asset('storage/'.$brt->gambar)); ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($brt->judul); ?></h5>
              <p class="card-text"><?php echo e(substr(strip_tags($brt->body),0, 300)); ?> ... <a href="<?php echo e(url('berita/'.$brt->slug)); ?>" class="text-decoration-none">Selengkapnya</a>
              <p class="card-text"><small class="text-muted"><?php echo e($brt->created_at->format('d/M/Y')); ?></small></p>
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($berita->links()); ?>

    </div>
    <div class="col-1"></div>
    <div class="col-md-3 mt-4">
        <h4 class="bg-secondary text-center text-light p-1">Terakhir diupdate</h4>

        <?php $__currentLoopData = $recentberita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" >
          
          <div class="card-body">
            <h6 class="card-title"><a href="<?php echo e(url('berita/'.$recent->slug)); ?>" class="text-decoration-none text-dark"><?php echo e($recent->judul); ?></a></h6>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/berita.blade.php ENDPATH**/ ?>