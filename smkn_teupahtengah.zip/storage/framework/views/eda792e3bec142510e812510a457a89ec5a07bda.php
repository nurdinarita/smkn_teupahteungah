

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            <?php echo e(!isset($struktur) ? 'Tambah Struktur Organisasi' : 'Edit Struktur Organisasi'); ?>

          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(isset($struktur) ? url('admin/struktur-organisasi/'.$struktur->id) : url('admin/struktur-organisasi/')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($struktur)): ?>
            <?php echo method_field('patch'); ?>
            <?php endif; ?>
            <div class="mb-1">
              <label for="judul">Tahun</label>
              <input type="text" name="tahun" class="form-control" id="tahun" placeholder="Tahun" value="<?php echo e(isset($struktur) ? $struktur->tahun : old('tahun')); ?>" required>
            </div>
            <div class="mb-1">
              <label for="gambar">Gambar</label>
              <?php if(isset($struktur)): ?>
                <br>
                <img src="<?php echo e(asset('storage/'.$struktur->gambar)); ?>" alt="" class="img-thumbnail" width="200px">
              <?php endif; ?>
              <input type="file" class="form-control" name="gambar" id="gambar" <?php echo e(!isset($struktur) ? 'required' : ''); ?>>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/struktur/form.blade.php ENDPATH**/ ?>