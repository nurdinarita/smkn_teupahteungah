

<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            Edit Visi Dan Misi Sekolah
          </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
        <form action="<?php echo e(url('admin/visi-misi/'.$visimisi->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <label for="summernotevisi">Visi Sekolah</label>
            <textarea id="summernotevisi" name="visi" required>
              <?php echo e($visimisi->visi); ?>

            </textarea>

            <label for="summernotemisi">Misi Sekolah</label>
            <textarea id="summernotemisi" name="misi" required>
              <?php echo e($visimisi->misi); ?>

            </textarea>
            <button type="submit" class="btn btn-primary">Update Profil</button>
        </form>
        </div>
      </div>
    </div>
    <!-- /.col-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/admin/visi-misi/form.blade.php ENDPATH**/ ?>