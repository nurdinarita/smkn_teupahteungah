

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Alumni SMKN 1 Teupah Tengah</h4>
            <div class="container">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th class="col-1">No</th>
                      <th>Tahun Lulus</th>
                      <th>Nama Alumni</th>
                      <th>Status Alumni</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($alumni->tahun); ?></td>
                      <td><?php echo e($alumni->nama); ?></td>
                      <td><?php echo e($alumni->status); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                      <th>No</th>
                      <th>Tahun Lulus</th>
                      <th>Nama Alumni</th>
                      <th>Status Alumni</th>
                    </tr>
                    </tfoot>
                  </table>
            </div> 
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/alumni.blade.php ENDPATH**/ ?>