

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Dewan Guru</h4>
            <div class="container">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th class="col-1">No</th>
                      <th>NIP</th>
                      <th>Nama Guru</th>
                      <th>Mata Pelajaran</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($guru->nip); ?></td>
                      <td><?php echo e($guru->nama); ?></td>
                      <td><?php echo e($guru->mata_pelajaran); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                      <th>No</th>
                      <th>NIP</th>
                      <th>Nama Guru</th>
                      <th>Mata Pelajaran</th>
                    </tr>
                    </tfoot>
                  </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/guru.blade.php ENDPATH**/ ?>