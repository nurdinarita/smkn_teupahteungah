

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<section>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h4 class="bg-secondary text-center text-light p-2">Pendaftaran SMKN 1 Teupah Tengah</h4>
            <div class="container">
                <?php if(isset($pendaftaran)): ?>
                <p>
                    <?php echo $pendaftaran->body; ?>

                </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\smkn_teupahtengah\resources\views/pages/pendaftaran.blade.php ENDPATH**/ ?>